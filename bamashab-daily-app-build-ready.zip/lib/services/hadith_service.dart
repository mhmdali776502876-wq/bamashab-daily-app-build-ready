import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../data/hadith_model.dart';

class HadithService {
  List<Hadith>? _hadiths;

  /// Loads all Hadiths from the local JSON asset file.
  Future<void> loadHadiths() async {
    final jsonString = await rootBundle.loadString('lib/data/hadiths.json');
    final List<dynamic> jsonList = json.decode(jsonString);
    _hadiths = jsonList.map((j) => Hadith.fromJson(j)).toList();
  }

  /// Returns the Hadith for today, deterministically using day-of-year index.
  /// Same Hadith for everyone on the same day.
  Hadith getTodayHadith() {
    if (_hadiths == null || _hadiths!.isEmpty) {
      return const Hadith(
        text: 'إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى',
        source: 'متفق عليه',
      );
    }

    final dayOfYear = DateTime.now().difference(DateTime(DateTime.now().year, 1, 1)).inDays;
    final index = dayOfYear % _hadiths!.length;
    return _hadiths![index];
  }

  /// Returns the total number of Hadiths loaded
  int get count => _hadiths?.length ?? 0;
}
