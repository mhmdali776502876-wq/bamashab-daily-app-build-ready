import 'package:intl/intl.dart' hide TextDirection;
import 'package:hijri/hijri_calendar.dart';

/// Information about the current Gregorian date
class GregorianDateInfo {
  final int day;
  final String monthName;
  final int year;
  final String weekday;
  final String monthGulfName;

  const GregorianDateInfo({
    required this.day,
    required this.monthName,
    required this.year,
    required this.weekday,
    required this.monthGulfName,
  });
}

/// Information about the current Hijri date
class HijriDateInfo {
  final int day;
  final String monthName;
  final int year;

  const HijriDateInfo({
    required this.day,
    required this.monthName,
    required this.year,
  });
}

/// Maps Gregorian month number (1-12) to Gulf-style Arabic name
/// e.g. "أغسطس (آب)"
const Map<int, String> gulfMonthNames = {
  1: 'يناير (كانون الثاني)',
  2: 'فبراير (شباط)',
  3: 'مارس (آذار)',
  4: 'أبريل (نيسان)',
  5: 'مايو (أيار)',
  6: 'يونيو (حزيران)',
  7: 'يوليو (تموز)',
  8: 'أغسطس (آب)',
  9: 'سبتمبر (أيلول)',
  10: 'أكتوبر (تشرين الأول)',
  11: 'نوفمبر (تشرين الثاني)',
  12: 'ديسمبر (كانون الأول)',
};

class DateEngine {
  /// Gets the current Gregorian date info
  static GregorianDateInfo getGregorianDate() {
    final now = DateTime.now();

    return GregorianDateInfo(
      day: now.day,
      monthName: DateFormat('MMMM', 'ar').format(now),
      year: now.year,
      weekday: DateFormat('EEEE', 'ar').format(now),
      monthGulfName: gulfMonthNames[now.month] ?? '',
    );
  }

  /// Gets the current Hijri date info using Umm al-Qura calendar
  static HijriDateInfo getHijriDate() {
    final today = HijriCalendar.now();

    return HijriDateInfo(
      day: today.hDay,
      monthName: today.longMonthName,
      year: today.hYear,
    );
  }
}
