import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'hadith_service.dart';
import 'date_engine.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._();
  factory NotificationService() => _instance;
  NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);
    _initialized = true;
  }

  /// Schedules a daily notification at the configured time (default 7:00 AM).
  Future<void> scheduleDailyNotification({
    int hour = 7,
    int minute = 0,
  }) async {
    await initialize();

    // Cancel all existing scheduled notifications first
    await _plugin.cancelAll();

    // Get today's Hadith for the notification content
    final hadithService = HadithService();
    await hadithService.loadHadiths();
    final hadith = hadithService.getTodayHadith();
    final date = DateEngine.getGregorianDate();

    const androidDetails = AndroidNotificationDetails(
      'daily_hadith_channel',
      'الحديث اليومي',
      channelDescription: 'إشعار يومي بالحديث الشريف',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
      icon: '@mipmap/ic_launcher',
      styleInformation: BigTextStyleInformation(''),
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    // Schedule daily notification
    await _plugin.periodicallyShow(
      0, // id
      'حديث اليوم - ${date.weekday} ${date.day} ${date.monthName}',
      hadith.text,
      RepeatInterval.daily,
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  /// Cancels all scheduled notifications
  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }

  /// Check if notifications are enabled in settings
  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('notifications_enabled') ?? false;
  }

  /// Get the configured notification time
  Future<Map<String, int>> getNotificationTime() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'hour': prefs.getInt('notification_hour') ?? 7,
      'minute': prefs.getInt('notification_minute') ?? 0,
    };
  }
}
