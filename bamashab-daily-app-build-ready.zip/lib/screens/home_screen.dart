import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../main.dart';
import '../providers/date_provider.dart';
import '../services/hadith_service.dart';
import '../widgets/app_header.dart';
import '../widgets/date_card.dart';
import '../widgets/hadith_card.dart';
import '../widgets/app_footer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final ScreenshotController _screenshotController = ScreenshotController();
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeIn,
    );
    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _shareAsImage() async {
    try {
      final Uint8List? imageBytes = await _screenshotController.capture(
        delay: const Duration(milliseconds: 100),
        pixelRatio: 3.0, // High quality for sharing
      );

      if (imageBytes == null) return;

      final directory = await getTemporaryDirectory();
      final imagePath = '${directory.path}/bamashab_daily.png';
      final imageFile = File(imagePath);
      await imageFile.writeAsBytes(imageBytes);

      await Share.shareXFiles(
        [XFile(imagePath)],
        text: 'بامخشب اليومية - حديث اليوم',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ أثناء المشاركة: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateProvider = context.watch<DateProvider>();
    final hadithService = HadithService();
    final todayHadith = hadithService.getTodayHadith();

    final greg = dateProvider.gregorianDate;
    final hijri = dateProvider.hijriDate;

    return Scaffold(
      backgroundColor: BamashabDailyApp.cream,
      appBar: AppBar(
        backgroundColor: BamashabDailyApp.cream,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.settings_outlined),
          onPressed: () => Navigator.pushNamed(context, '/settings'),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.share_outlined,
              color: BamashabDailyApp.orange,
            ),
            onPressed: _shareAsImage,
            tooltip: 'مشاركة كصورة',
          ),
        ],
        title: Text(
          'بامخشب اليومية',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.w700,
            color: BamashabDailyApp.inkBlack,
            fontSize: 18,
          ),
        ),
      ),
      body: Screenshot(
        controller: _screenshotController,
        child: Container(
          color: BamashabDailyApp.cream,
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Column(
                  children: [
                    // ─── Header Card ───
                    const AppHeader(),
                    const SizedBox(height: 20),

                    // ─── Date Section ───
                    if (greg != null && hijri != null) ...[
                      _buildDateSection(greg, hijri),
                    ] else
                      const Center(
                        child: CircularProgressIndicator(
                          color: BamashabDailyApp.orange,
                        ),
                      ),
                    const SizedBox(height: 20),

                    // ─── Hadith Card ───
                    HadithCard(hadith: todayHadith),
                    const SizedBox(height: 20),

                    // ─── Footer ───
                    const AppFooter(),

                    // Bottom padding for scrolling
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the side-by-side date section with divider.
  /// Gregorian on the right (for RTL) and Hijri on the left.
  Widget _buildDateSection(dynamic greg, dynamic hijri) {
    return Column(
      children: [
        // Date cards row
        Row(
          children: [
            // Hijri date (left/trailing in RTL? No — right side in Arabic layout)
            Expanded(
              child: DateCard(
                label: 'التاريخ الهجري',
                weekday: '', // Hijri doesn't have weekday
                day: hijri.day,
                month: hijri.monthName,
                year: hijri.year,
                footerLabel: 'أم القرى',
                yearSuffix: ' هـ',
              ),
            ),
            // Divider column
            _buildDateDivider(),
            // Gregorian date
            Expanded(
              child: DateCard(
                label: 'التاريخ الميلادي',
                weekday: greg.weekday,
                day: greg.day,
                month: greg.monthName,
                year: greg.year,
                footerLabel: greg.monthGulfName,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // "اليوم / التاريخ" label below
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: BamashabDailyApp.inkBlack.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '۞  اليوم / التاريخ  ۞',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w700,
              fontSize: 12,
              color: BamashabDailyApp.mutedGray,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDateDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        children: [
          Container(
            width: 1.5,
            height: 30,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  BamashabDailyApp.orange.withValues(alpha: 0.5),
                ],
              ),
            ),
          ),
          Icon(
            Icons.more_vert,
            size: 16,
            color: BamashabDailyApp.orange.withValues(alpha: 0.4),
          ),
          Container(
            width: 1.5,
            height: 30,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  BamashabDailyApp.orange.withValues(alpha: 0.5),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
