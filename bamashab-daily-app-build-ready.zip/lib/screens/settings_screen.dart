import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../main.dart';
import '../providers/settings_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _phone1Controller = TextEditingController();
  final _phone2Controller = TextEditingController();
  final _addressController = TextEditingController();
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final settings = context.read<SettingsProvider>();
      _phone1Controller.text = settings.phone1;
      _phone2Controller.text = settings.phone2;
      _addressController.text = settings.address;
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _phone1Controller.dispose();
    _phone2Controller.dispose();
    _addressController.dispose();
    super.dispose();
  }

  Future<void> _pickTime(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final picked = await showTimePicker(
      context: context,
      initialTime: settings.notificationTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: BamashabDailyApp.orange,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      await settings.setNotificationTime(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return Scaffold(
      backgroundColor: BamashabDailyApp.cream,
      appBar: AppBar(
        title: Text(
          'الإعدادات',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.w700,
            color: BamashabDailyApp.inkBlack,
            fontSize: 18,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ─── Notification Settings ───
            _buildSectionHeader('🔔  إعدادات الإشعارات'),
            const SizedBox(height: 8),
            _buildCard(
              children: [
                // Toggle
                SwitchListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  title: Text(
                    'تفعيل الإشعار اليومي',
                    style: GoogleFonts.tajawal(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: BamashabDailyApp.inkBlack,
                    ),
                  ),
                  subtitle: Text(
                    'استلام إشعار يومي بالحديث الشريف',
                    style: GoogleFonts.tajawal(
                      fontSize: 12,
                      color: BamashabDailyApp.mutedGray,
                    ),
                  ),
                  value: settings.notificationsEnabled,
                  activeTrackColor: BamashabDailyApp.orange,
                  onChanged: (value) {
                    settings.setNotificationsEnabled(value);
                  },
                ),
                // Time picker
                if (settings.notificationsEnabled) ...[
                  const Divider(height: 1),
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    leading: const Icon(
                      Icons.access_time,
                      color: BamashabDailyApp.orange,
                    ),
                    title: Text(
                      'وقت الإشعار',
                      style: GoogleFonts.tajawal(
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                    ),
                    trailing: TextButton(
                      onPressed: () => _pickTime(context),
                      child: Text(
                        settings.notificationTime.format(context),
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          color: BamashabDailyApp.deepOrange,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 24),

            // ─── Contact Info ───
            _buildSectionHeader('📞  معلومات التواصل'),
            const SizedBox(height: 8),
            _buildCard(
              children: [
                _buildTextField(
                  controller: _phone1Controller,
                  label: 'رقم الهاتف الأول',
                  icon: Icons.phone,
                  onChanged: (v) => settings.setPhone1(v),
                ),
                const SizedBox(height: 12),
                _buildTextField(
                  controller: _phone2Controller,
                  label: 'رقم الهاتف الثاني',
                  icon: Icons.phone_android,
                  onChanged: (v) => settings.setPhone2(v),
                ),
                const SizedBox(height: 12),
                _buildTextField(
                  controller: _addressController,
                  label: 'العنوان',
                  icon: Icons.location_on,
                  maxLines: 2,
                  onChanged: (v) => settings.setAddress(v),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // ─── About ───
            _buildSectionHeader('ℹ️  حول التطبيق'),
            const SizedBox(height: 8),
            _buildCard(
              children: [
                ListTile(
                  leading: const Icon(
                    Icons.info_outline,
                    color: BamashabDailyApp.orange,
                  ),
                  title: Text(
                    'بامخشب اليومية',
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                  subtitle: Text(
                    'الإصدار 1.0.0\nمجمع بامخشب لخدمات السيارات - اليمن',
                    style: GoogleFonts.tajawal(
                      fontSize: 12,
                      color: BamashabDailyApp.mutedGray,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String text) {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: Text(
        text,
        style: GoogleFonts.cairo(
          fontWeight: FontWeight.w700,
          fontSize: 15,
          color: BamashabDailyApp.inkBlack,
        ),
      ),
    );
  }

  Widget _buildCard({required List<Widget> children}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: BamashabDailyApp.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: children,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    int maxLines = 1,
    required ValueChanged<String> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        onChanged: onChanged,
        style: GoogleFonts.tajawal(
          fontSize: 14,
          color: BamashabDailyApp.inkBlack,
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: GoogleFonts.tajawal(
            fontSize: 13,
            color: BamashabDailyApp.mutedGray,
          ),
          prefixIcon: Icon(icon, size: 20, color: BamashabDailyApp.orange),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: BamashabDailyApp.inkBlack.withValues(alpha: 0.12),
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: BamashabDailyApp.inkBlack.withValues(alpha: 0.12),
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: BamashabDailyApp.orange),
          ),
          filled: true,
          fillColor: BamashabDailyApp.cream,
        ),
      ),
    );
  }
}
