import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'providers/date_provider.dart';
import 'providers/settings_provider.dart';
import 'services/hadith_service.dart';
import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load Hadiths from JSON asset
  final hadithService = HadithService();
  await hadithService.loadHadiths();

  runApp(const BamashabDailyApp());
}

class BamashabDailyApp extends StatelessWidget {
  const BamashabDailyApp({super.key});

  // ─── Design System Colors ───
  static const Color inkBlack = Color(0xFF171512);
  static const Color orange = Color(0xFFF0891E);
  static const Color deepOrange = Color(0xFFD9720E);
  static const Color cream = Color(0xFFFBF7F1);
  static const Color white = Color(0xFFFFFFFF);
  static const Color mutedGray = Color(0xFF8A8A8A);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DateProvider()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()..loadSettings()),
      ],
      child: MaterialApp(
        title: 'بامخشب اليومية',
        debugShowCheckedModeBanner: false,

        // Force RTL for Arabic
        locale: const Locale('ar', 'SA'),
        supportedLocales: const [Locale('ar', 'SA')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],

        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          scaffoldBackgroundColor: cream,
          colorScheme: const ColorScheme.light(
            primary: orange,
            secondary: deepOrange,
            surface: white,
            onSurface: inkBlack,
          ),
          // Default text theme using Cairo family
          textTheme: GoogleFonts.cairoTextTheme().copyWith(
            headlineLarge: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              color: inkBlack,
              fontSize: 28,
            ),
            headlineMedium: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              color: inkBlack,
              fontSize: 22,
            ),
            titleLarge: GoogleFonts.cairo(
              fontWeight: FontWeight.w700,
              color: inkBlack,
              fontSize: 18,
            ),
            titleMedium: GoogleFonts.tajawal(
              fontWeight: FontWeight.w500,
              color: inkBlack,
              fontSize: 16,
            ),
            bodyLarge: GoogleFonts.tajawal(
              fontWeight: FontWeight.w400,
              color: inkBlack,
              fontSize: 15,
            ),
            bodyMedium: GoogleFonts.tajawal(
              fontWeight: FontWeight.w400,
              color: inkBlack,
              fontSize: 13,
            ),
            labelLarge: GoogleFonts.cairo(
              fontWeight: FontWeight.w700,
              color: white,
              fontSize: 14,
            ),
          ),
          appBarTheme: AppBarTheme(
            backgroundColor: cream,
            elevation: 0,
            centerTitle: true,
            titleTextStyle: GoogleFonts.cairo(
              fontWeight: FontWeight.w700,
              color: inkBlack,
              fontSize: 18,
            ),
            iconTheme: const IconThemeData(color: inkBlack),
          ),
        ),

        home: const HomeScreen(),
        routes: {
          '/settings': (context) => const SettingsScreen(),
        },
      ),
    );
  }
}
