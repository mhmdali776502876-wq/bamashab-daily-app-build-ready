import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/notification_service.dart';

class SettingsProvider extends ChangeNotifier {
  bool _notificationsEnabled = false;
  TimeOfDay _notificationTime = const TimeOfDay(hour: 7, minute: 0);
  String _phone1 = '777777777';
  String _phone2 = '712345678';
  String _address = 'اليمن، صنعاء';

  bool get notificationsEnabled => _notificationsEnabled;
  TimeOfDay get notificationTime => _notificationTime;
  String get phone1 => _phone1;
  String get phone2 => _phone2;
  String get address => _address;

  /// Load all settings from SharedPreferences
  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _notificationsEnabled = prefs.getBool('notifications_enabled') ?? false;
    final hour = prefs.getInt('notification_hour') ?? 7;
    final minute = prefs.getInt('notification_minute') ?? 0;
    _notificationTime = TimeOfDay(hour: hour, minute: minute);
    _phone1 = prefs.getString('phone1') ?? '777777777';
    _phone2 = prefs.getString('phone2') ?? '712345678';
    _address = prefs.getString('address') ?? 'اليمن، صنعاء';
    notifyListeners();
  }

  /// Toggle daily notification on/off
  Future<void> setNotificationsEnabled(bool value) async {
    _notificationsEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', value);

    if (value) {
      await NotificationService().scheduleDailyNotification(
        hour: _notificationTime.hour,
        minute: _notificationTime.minute,
      );
    } else {
      await NotificationService().cancelAll();
    }

    notifyListeners();
  }

  /// Update the notification time
  Future<void> setNotificationTime(TimeOfDay time) async {
    _notificationTime = time;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('notification_hour', time.hour);
    await prefs.setInt('notification_minute', time.minute);

    if (_notificationsEnabled) {
      await NotificationService().scheduleDailyNotification(
        hour: time.hour,
        minute: time.minute,
      );
    }

    notifyListeners();
  }

  /// Update contact info
  Future<void> setPhone1(String value) async {
    _phone1 = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('phone1', value);
    notifyListeners();
  }

  Future<void> setPhone2(String value) async {
    _phone2 = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('phone2', value);
    notifyListeners();
  }

  Future<void> setAddress(String value) async {
    _address = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('address', value);
    notifyListeners();
  }
}
