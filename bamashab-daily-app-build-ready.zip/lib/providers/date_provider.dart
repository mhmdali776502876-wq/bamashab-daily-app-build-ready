import 'dart:async';
import 'package:flutter/material.dart';
import '../services/date_engine.dart';

class DateProvider extends ChangeNotifier {
  GregorianDateInfo? _gregorianDate;
  HijriDateInfo? _hijriDate;
  Timer? _midnightTimer;

  GregorianDateInfo? get gregorianDate => _gregorianDate;
  HijriDateInfo? get hijriDate => _hijriDate;

  DateProvider() {
    _refreshDates();
    _scheduleMidnightRefresh();
  }

  void _refreshDates() {
    _gregorianDate = DateEngine.getGregorianDate();
    _hijriDate = DateEngine.getHijriDate();
    notifyListeners();
  }

  /// Schedule a refresh at the next midnight (local time)
  void _scheduleMidnightRefresh() {
    final now = DateTime.now();
    final nextMidnight = DateTime(now.year, now.month, now.day + 1);
    final durationUntilMidnight = nextMidnight.difference(now);

    _midnightTimer?.cancel();
    _midnightTimer = Timer(durationUntilMidnight, () {
      _refreshDates();
      _scheduleMidnightRefresh(); // Re-schedule for the next midnight
    });
  }

  @override
  void dispose() {
    _midnightTimer?.cancel();
    super.dispose();
  }
}
