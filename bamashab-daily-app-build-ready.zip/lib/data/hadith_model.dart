/// بيانات الحديث الواحد من ملف JSON
class Hadith {
  final String text;
  final String source;

  const Hadith({required this.text, required this.source});

  factory Hadith.fromJson(Map<String, dynamic> json) {
    return Hadith(
      text: json['text'] as String,
      source: json['source'] as String,
    );
  }

  Map<String, dynamic> toJson() => {'text': text, 'source': source};
}
