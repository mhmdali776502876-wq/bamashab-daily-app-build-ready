import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../main.dart';

/// A single date card for either Gregorian or Hijri date display.
/// Shows an orange pill label at top, weekday, large orange number,
/// month/year, and a footer label.
class DateCard extends StatelessWidget {
  final String label;
  final String weekday;
  final int day;
  final String month;
  final int year;
  final String footerLabel;
  final String yearSuffix; // e.g. "" for Gregorian, "هـ" for Hijri

  const DateCard({
    super.key,
    required this.label,
    required this.weekday,
    required this.day,
    required this.month,
    required this.year,
    required this.footerLabel,
    this.yearSuffix = '',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: BamashabDailyApp.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Top pill label
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: BamashabDailyApp.orange,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              label,
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.w600,
                fontSize: 11,
                color: Colors.white,
              ),
            ),
          ),
          if (weekday.isNotEmpty) ...[
            const SizedBox(height: 8),
            // Weekday
            Text(
              weekday,
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.w400,
                fontSize: 13,
                color: BamashabDailyApp.mutedGray,
              ),
            ),
          ],
          const SizedBox(height: 2),
          // Day number (large, orange)
          Text(
            '$day',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              fontSize: 40,
              color: BamashabDailyApp.deepOrange,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 4),
          // Month and year
          Text(
            '$month $year$yearSuffix',
            style: GoogleFonts.tajawal(
              fontWeight: FontWeight.w500,
              fontSize: 12,
              color: BamashabDailyApp.inkBlack,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          // Bottom pill label
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: BoxDecoration(
              color: BamashabDailyApp.orange.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              footerLabel,
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.w600,
                fontSize: 10,
                color: BamashabDailyApp.orange,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
