import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../providers/settings_provider.dart';

/// Footer bar with black background, phone icons + numbers,
/// location pin + address, and a circular white logo badge.
class AppFooter extends StatelessWidget {
  const AppFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: BamashabDailyApp.inkBlack,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          // Phone + Location info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Phone 1
                _buildInfoRow(
                  icon: Icons.phone,
                  text: settings.phone1,
                ),
                const SizedBox(height: 6),
                // Phone 2
                _buildInfoRow(
                  icon: Icons.phone_android,
                  text: settings.phone2,
                ),
                const SizedBox(height: 6),
                // Address
                _buildInfoRow(
                  icon: Icons.location_on,
                  text: settings.address,
                  isAddress: true,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // Circular white logo badge
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.all(6),
            child: Image.asset(
              'assets/images/logo.png',
              fit: BoxFit.contain,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String text,
    bool isAddress = false,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          size: 14,
          color: BamashabDailyApp.orange,
        ),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            text,
            style: GoogleFonts.tajawal(
              fontWeight: FontWeight.w400,
              fontSize: 11,
              color: Colors.white.withValues(alpha: 0.85),
            ),
            maxLines: isAddress ? 2 : 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
