import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../main.dart';
import '../data/hadith_model.dart';

/// White card with orange border displaying the Hadith of the day.
/// Has a floating pill badge "💬 حديث اليوم" overlapping the top edge,
/// centered justified Arabic text with key words in orange bold,
/// and source citation bottom-left in muted gray.
class HadithCard extends StatelessWidget {
  final Hadith hadith;

  const HadithCard({super.key, required this.hadith});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Main card
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(top: 16),
          padding: const EdgeInsets.fromLTRB(20, 32, 20, 20),
          decoration: BoxDecoration(
            color: BamashabDailyApp.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: BamashabDailyApp.orange.withValues(alpha: 0.4),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: BamashabDailyApp.orange.withValues(alpha: 0.08),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Hadith text
              _buildHadithText(),
              const SizedBox(height: 16),
              // Source citation
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '— ${hadith.source}',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: BamashabDailyApp.mutedGray,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Floating pill badge
        Positioned(
          top: -14,
          right: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: BamashabDailyApp.orange,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: BamashabDailyApp.orange.withValues(alpha: 0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              '💬 حديث اليوم',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w700,
                fontSize: 13,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds Hadith text with key words highlighted in orange bold.
  Widget _buildHadithText() {
    final text = hadith.text;

    // Key religious words to highlight in orange bold
    final highlightWords = [
      'الله',
      'رسول',
      'الإسلام',
      'المسلم',
      'المسلمون',
      'الإيمان',
      'المؤمن',
      'المؤمنون',
      'القرآن',
      'الجنة',
      'النار',
      'الصلاة',
      'الصيام',
      'الزكاة',
      'الحج',
      'رمضان',
      'الرحمن',
      'القيامة',
      'الجمعة',
      'العلم',
      'الصدقة',
      'الذكر',
      'الدعاء',
      'التقوى',
      'الجهاد',
    ];

    // Build rich text with highlighted spans
    final spans = <TextSpan>[];
    final words = text.split(' ');
    for (int i = 0; i < words.length; i++) {
      final word = words[i];
      final cleanWord = word.replaceAll(RegExp(r'[،؛:\.\!]$'), '');
      final suffix = word.replaceAll(cleanWord, '');

      final isHighlighted = highlightWords.any(
        (h) => cleanWord.contains(h) || h.contains(cleanWord),
      );

      spans.add(
        TextSpan(
          text: cleanWord,
          style: GoogleFonts.tajawal(
            fontWeight: isHighlighted ? FontWeight.w700 : FontWeight.w400,
            fontSize: 16,
            color: isHighlighted
                ? BamashabDailyApp.deepOrange
                : BamashabDailyApp.inkBlack,
            height: 1.8,
          ),
        ),
      );

      if (suffix.isNotEmpty) {
        spans.add(
          TextSpan(
            text: suffix,
            style: GoogleFonts.tajawal(
              fontWeight: FontWeight.w400,
              fontSize: 16,
              color: BamashabDailyApp.inkBlack,
              height: 1.8,
            ),
          ),
        );
      }

      if (i < words.length - 1) {
        spans.add(
          TextSpan(
            text: ' ',
            style: GoogleFonts.tajawal(fontSize: 16),
          ),
        );
      }
    }

    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(children: spans),
    );
  }
}
