import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../main.dart';

/// Top header card with black background, logo, and brand name.
class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final logoSize = screenWidth * 0.45;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: BamashabDailyApp.inkBlack,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Logo image
          Image.asset(
            'assets/images/logo.png',
            width: logoSize,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 12),
          // Brand name
          Text(
            'مجمع بامخشب لخدمات السيارات',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            'بطاقة اليومية',
            style: GoogleFonts.tajawal(
              fontWeight: FontWeight.w400,
              fontSize: 13,
              color: BamashabDailyApp.orange,
            ),
          ),
        ],
      ),
    );
  }
}
